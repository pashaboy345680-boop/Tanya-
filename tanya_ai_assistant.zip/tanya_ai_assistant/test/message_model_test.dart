import 'package:flutter_test/flutter_test.dart';
import 'package:tanya_ai_assistant/models/message_model.dart';

void main() {
  group('MessageModel', () {
    test('serializes to and from a map correctly', () {
      final message = MessageModel(
        id: 'msg1',
        chatId: 'chat1',
        text: 'Namaste Tanya!',
        isUser: true,
        timestamp: DateTime(2026, 1, 1, 10, 30),
      );

      final map = message.toMap();
      final rebuilt = MessageModel.fromMap(map);

      expect(rebuilt.id, message.id);
      expect(rebuilt.chatId, message.chatId);
      expect(rebuilt.text, message.text);
      expect(rebuilt.isUser, message.isUser);
      expect(rebuilt.timestamp, message.timestamp);
    });

    test('copyWith updates sync status without mutating original fields', () {
      final message = MessageModel(
        id: 'msg2',
        chatId: 'chat1',
        text: 'Kaise ho?',
        isUser: false,
        timestamp: DateTime.now(),
        isSynced: false,
      );

      final synced = message.copyWith(isSynced: true);

      expect(synced.isSynced, true);
      expect(synced.text, message.text);
    });
  });
}
