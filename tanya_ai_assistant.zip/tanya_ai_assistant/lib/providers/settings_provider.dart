import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/constants/app_constants.dart';

/// Holds user-configurable app settings: dark mode, voice replies on/off,
/// and Tanya's preferred reply language. Persisted via SharedPreferences
/// so they survive app restarts.
class SettingsProvider extends ChangeNotifier {
  bool isDarkMode = true;
  bool voiceRepliesEnabled = true;
  String preferredLanguage = 'hinglish'; // hindi | hinglish | english

  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    isDarkMode = _prefs?.getBool(AppConstants.keyDarkMode) ?? true;
    voiceRepliesEnabled = _prefs?.getBool(AppConstants.keyVoiceReplies) ?? true;
    preferredLanguage = _prefs?.getString(AppConstants.keyPreferredLanguage) ?? 'hinglish';
    notifyListeners();
  }

  Future<void> toggleDarkMode(bool value) async {
    isDarkMode = value;
    await _prefs?.setBool(AppConstants.keyDarkMode, value);
    notifyListeners();
  }

  Future<void> toggleVoiceReplies(bool value) async {
    voiceRepliesEnabled = value;
    await _prefs?.setBool(AppConstants.keyVoiceReplies, value);
    notifyListeners();
  }

  Future<void> setPreferredLanguage(String language) async {
    preferredLanguage = language;
    await _prefs?.setString(AppConstants.keyPreferredLanguage, language);
    notifyListeners();
  }
}
