import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../core/services/auth_service.dart';
import '../models/user_model.dart';

enum AuthStatus { unknown, authenticated, unauthenticated }

/// App-wide authentication state, exposed via Provider to the whole tree.
class AuthProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();

  AuthStatus status = AuthStatus.unknown;
  UserModel? currentUser;
  String? errorMessage;
  bool isLoading = false;

  AuthProvider() {
    _authService.authStateChanges.listen(_onAuthChanged);
  }

  Future<void> _onAuthChanged(User? user) async {
    if (user == null) {
      status = AuthStatus.unauthenticated;
      currentUser = null;
    } else {
      final profile = await _authService.fetchUserProfile(user.uid);
      currentUser = profile ??
          UserModel(uid: user.uid, name: user.displayName ?? 'Dost', email: user.email ?? '', createdAt: DateTime.now());
      status = AuthStatus.authenticated;
    }
    notifyListeners();
  }

  Future<bool> signUp({required String name, required String email, required String password}) async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();
    try {
      final user = await _authService.signUp(name: name, email: email, password: password);
      currentUser = user;
      status = AuthStatus.authenticated;
      return true;
    } on FirebaseAuthException catch (e) {
      errorMessage = _friendlyError(e);
      return false;
    } catch (e) {
      errorMessage = 'Kuch galat ho gaya. Please try again.';
      return false;
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> signIn({required String email, required String password}) async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();
    try {
      final user = await _authService.signIn(email: email, password: password);
      currentUser = user;
      status = AuthStatus.authenticated;
      return true;
    } on FirebaseAuthException catch (e) {
      errorMessage = _friendlyError(e);
      return false;
    } catch (e) {
      errorMessage = 'Login nahi ho paaya. Please try again.';
      return false;
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> sendPasswordReset(String email) async {
    try {
      await _authService.sendPasswordReset(email);
      return true;
    } catch (e) {
      errorMessage = 'Reset email bhejne mein problem hui.';
      notifyListeners();
      return false;
    }
  }

  Future<void> signOut() async {
    await _authService.signOut();
    currentUser = null;
    status = AuthStatus.unauthenticated;
    notifyListeners();
  }

  Future<void> updateProfile({required String name, String? photoUrl}) async {
    if (currentUser == null) return;
    currentUser = currentUser!.copyWith(name: name, photoUrl: photoUrl);
    await _authService.updateProfile(currentUser!);
    notifyListeners();
  }

  String _friendlyError(FirebaseAuthException e) {
    switch (e.code) {
      case 'email-already-in-use':
        return 'Yeh email pehle se registered hai.';
      case 'invalid-email':
        return 'Please ek valid email address daalein.';
      case 'weak-password':
        return 'Password kam se kam 6 characters ka hona chahiye.';
      case 'user-not-found':
      case 'invalid-credential':
        return 'Email ya password galat hai.';
      case 'wrong-password':
        return 'Password galat hai. Please dobara try karein.';
      case 'too-many-requests':
        return 'Bahut zyada attempts ho gaye. Thodi der baad try karein.';
      default:
        return e.message ?? 'Authentication mein error aaya.';
    }
  }
}
