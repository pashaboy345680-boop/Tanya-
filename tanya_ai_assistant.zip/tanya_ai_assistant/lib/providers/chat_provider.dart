import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import '../core/services/gemini_service.dart';
import '../core/services/firestore_service.dart';
import '../core/services/local_cache_service.dart';
import '../core/services/connectivity_service.dart';
import '../core/services/tts_service.dart';
import '../models/message_model.dart';
import '../models/chat_session_model.dart';

/// The heart of Tanya's chat experience. Coordinates:
/// - Sending user messages to Gemini and receiving replies
/// - Persisting messages to Firestore when online
/// - Caching every message locally with Hive for offline access
/// - Queuing messages sent while offline and flushing them once reconnected
/// - Speaking Tanya's replies aloud via TTS (if enabled)
class ChatProvider extends ChangeNotifier {
  final GeminiService _gemini = GeminiService();
  final FirestoreService _firestore = FirestoreService();
  final LocalCacheService _cache = LocalCacheService();
  final ConnectivityService _connectivity = ConnectivityService();
  final TtsService _tts = TtsService();
  final _uuid = const Uuid();

  String? uid;
  String? activeChatId;
  List<MessageModel> messages = [];
  bool isTanyaTyping = false;
  bool isOnline = true;
  String? errorMessage;

  bool get isGeminiConfigured => _gemini.isConfigured;

  Future<void> init(String userId) async {
    uid = userId;
    await _cache.init();
    await _tts.init();
    isOnline = await _connectivity.isOnline();
    _connectivity.onConnectivityChanged.listen((online) {
      isOnline = online;
      if (online) _flushPendingMessages();
      notifyListeners();
    });
  }

  /// Starts a brand-new conversation thread.
  Future<void> startNewChat() async {
    if (uid == null) return;
    activeChatId = await _firestore.createChatSession(uid!);
    messages = [];
    _gemini.startSession();
    notifyListeners();
  }

  /// Loads an existing chat: tries the cache first (instant, offline-safe)
  /// then refreshes from Firestore if online.
  Future<void> openChat(String chatId) async {
    if (uid == null) return;
    activeChatId = chatId;
    messages = _cache.getCachedMessagesForChat(chatId);
    notifyListeners();

    if (isOnline) {
      try {
        final remote = await _firestore.fetchMessagesOnce(uid!, chatId);
        messages = remote;
        await _cache.cacheAllMessages(remote);
        notifyListeners();
      } catch (_) {
        // Keep showing cached messages if the fetch fails.
      }
    }

    // Rebuild Gemini's conversation memory from history so replies stay contextual.
    final history = messages
        .map((m) => Content(m.isUser ? 'user' : 'model', [TextPart(m.text)]))
        .toList();
    _gemini.startSession(history: history.isEmpty ? null : history);
  }

  /// Sends the user's [text] message, gets Tanya's reply, and persists both.
  Future<void> sendMessage(String text) async {
    if (text.trim().isEmpty || uid == null) return;
    errorMessage = null;

    if (activeChatId == null) {
      await startNewChat();
    }

    final userMessage = MessageModel(
      id: _uuid.v4(),
      chatId: activeChatId!,
      text: text.trim(),
      isUser: true,
      timestamp: DateTime.now(),
      isSynced: isOnline,
    );

    messages.add(userMessage);
    isTanyaTyping = true;
    notifyListeners();

    await _persistMessage(userMessage);

    // Auto-title the chat from the first user message.
    if (messages.where((m) => m.isUser).length == 1) {
      final title = text.trim().length > 40 ? '${text.trim().substring(0, 40)}...' : text.trim();
      if (isOnline) {
        await _firestore.updateChatSessionMeta(uid!, activeChatId!,
            title: title, lastMessagePreview: text.trim());
      }
    }

    try {
      final replyText = await _gemini.sendMessage(text.trim());
      final tanyaMessage = MessageModel(
        id: _uuid.v4(),
        chatId: activeChatId!,
        text: replyText,
        isUser: false,
        timestamp: DateTime.now(),
        isSynced: isOnline,
      );
      messages.add(tanyaMessage);
      await _persistMessage(tanyaMessage);

      if (isOnline) {
        await _firestore.updateChatSessionMeta(uid!, activeChatId!,
            title: _currentTitleGuess(), lastMessagePreview: replyText);
      }
    } catch (e) {
      errorMessage = e.toString().replaceFirst('Exception: ', '');
      final fallback = MessageModel(
        id: _uuid.v4(),
        chatId: activeChatId!,
        text: "Oops, mujhe jawab dete waqt thodi si problem ho gayi 😔 Please dobara try karein.",
        isUser: false,
        timestamp: DateTime.now(),
        isSynced: true,
      );
      messages.add(fallback);
      await _cache.cacheMessage(fallback);
    } finally {
      isTanyaTyping = false;
      notifyListeners();
    }
  }

  String _currentTitleGuess() {
    final firstUserMsg = messages.firstWhere((m) => m.isUser, orElse: () => messages.first);
    final t = firstUserMsg.text;
    return t.length > 40 ? '${t.substring(0, 40)}...' : t;
  }

  /// Persists a message: always to local cache, and to Firestore if online.
  /// If offline, the message is queued for later sync.
  Future<void> _persistMessage(MessageModel message) async {
    await _cache.cacheMessage(message);

    if (isOnline) {
      try {
        await _firestore.addMessage(uid!, message);
      } catch (_) {
        await _cache.queuePendingMessage(message);
      }
    } else {
      await _cache.queuePendingMessage(message);
    }
  }

  /// Uploads any messages that were queued while offline.
  Future<void> _flushPendingMessages() async {
    if (uid == null) return;
    final pending = _cache.getAllPendingMessages();
    for (final msg in pending) {
      try {
        await _firestore.addMessage(uid!, msg);
        await _cache.removePendingMessage(msg.id);
      } catch (_) {
        // Will retry on next reconnect.
      }
    }
  }

  Stream<List<ChatSessionModel>> chatSessionsStream() {
    if (uid == null) return const Stream.empty();
    return _firestore.streamChatSessions(uid!);
  }

  Future<void> deleteChat(String chatId) async {
    if (uid == null) return;
    await _cache.clearChatCache(chatId);
    if (isOnline) {
      await _firestore.deleteChatSession(uid!, chatId);
    }
    if (activeChatId == chatId) {
      activeChatId = null;
      messages = [];
      notifyListeners();
    }
  }

  Future<void> speakLastReply() async {
    final lastTanyaMsg = messages.lastWhere((m) => !m.isUser, orElse: () => messages.last);
    await _tts.speak(lastTanyaMsg.text);
  }

  Future<void> speakText(String text) => _tts.speak(text);
  Future<void> stopSpeaking() => _tts.stop();
}
