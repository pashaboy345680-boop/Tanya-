import 'package:flutter/material.dart';
import 'package:animate_do/animate_do.dart';
import 'package:intl/intl.dart';
import '../core/theme/app_theme.dart';
import '../models/message_model.dart';

/// A single chat bubble — styled differently for the user vs. Tanya,
/// with a tap-to-speak affordance on Tanya's replies.
class ChatBubble extends StatelessWidget {
  final MessageModel message;
  final VoidCallback? onSpeakTap;
  final bool isDark;

  const ChatBubble({
    super.key,
    required this.message,
    this.onSpeakTap,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    final isUser = message.isUser;
    final bubbleColor = isUser
        ? (isDark ? AppColors.darkBubbleUser : AppColors.lightBubbleUser)
        : (isDark ? AppColors.darkBubbleTanya : AppColors.lightBubbleTanya);
    final textColor = isUser ? Colors.white : (isDark ? Colors.white : const Color(0xFF1B1730));

    return FadeInUp(
      duration: const Duration(milliseconds: 280),
      from: 12,
      child: Align(
        alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 14),
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
          child: Column(
            crossAxisAlignment: isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
            children: [
              if (!isUser)
                Padding(
                  padding: const EdgeInsets.only(left: 6, bottom: 4),
                  child: Row(
                    children: [
                      Container(
                        width: 20,
                        height: 20,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(colors: AppColors.heroGradient),
                        ),
                        child: const Icon(Icons.auto_awesome, size: 12, color: Colors.white),
                      ),
                      const SizedBox(width: 6),
                      Text('Tanya',
                          style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: isDark ? Colors.white70 : Colors.black54)),
                    ],
                  ),
                ),
              GestureDetector(
                onLongPress: !isUser ? onSpeakTap : null,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: bubbleColor,
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(18),
                      topRight: const Radius.circular(18),
                      bottomLeft: Radius.circular(isUser ? 18 : 4),
                      bottomRight: Radius.circular(isUser ? 4 : 18),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(isDark ? 0.25 : 0.06),
                        blurRadius: 8,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Text(
                    message.text,
                    style: TextStyle(color: textColor, fontSize: 15.5, height: 1.4),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 4, left: 4, right: 4),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      DateFormat('h:mm a').format(message.timestamp),
                      style: TextStyle(
                          fontSize: 10.5, color: isDark ? Colors.white38 : Colors.black38),
                    ),
                    if (isUser && !message.isSynced) ...[
                      const SizedBox(width: 4),
                      Icon(Icons.schedule, size: 11, color: isDark ? Colors.white38 : Colors.black38),
                    ],
                    if (!isUser) ...[
                      const SizedBox(width: 6),
                      GestureDetector(
                        onTap: onSpeakTap,
                        child: Icon(Icons.volume_up_rounded,
                            size: 14, color: isDark ? Colors.white38 : Colors.black38),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
