/// Central place for all constant values used across the Tanya app.
class AppConstants {
  AppConstants._();

  // App info
  static const String appName = 'Tanya';
  static const String appTagline = 'Your Apna AI Saathi';

  // Firestore collection names
  static const String usersCollection = 'users';
  static const String chatsCollection = 'chats';
  static const String messagesSubcollection = 'messages';

  // Hive box names (used for offline caching)
  static const String messagesBox = 'tanya_messages_box';
  static const String settingsBox = 'tanya_settings_box';
  static const String pendingMessagesBox = 'tanya_pending_messages_box';

  // Shared preference keys
  static const String keyDarkMode = 'dark_mode_enabled';
  static const String keyVoiceReplies = 'voice_replies_enabled';
  static const String keyPreferredLanguage = 'preferred_language';
  static const String keyUserName = 'user_display_name';

  // Gemini model
  static const String geminiModel = 'gemini-1.5-flash';

  // Tanya's core personality / system instruction sent to Gemini.
  // This is what makes Tanya feel like a warm, witty Indian assistant who
  // can flow between Hindi, Hinglish and English naturally.
  static const String tanyaSystemPrompt = '''
You are Tanya, a friendly, warm, cheerful and polite Indian female AI assistant, created to feel like a helpful "apni" (our own) saathi/dost.

Personality rules:
- Speak naturally in a mix of Hindi, Hinglish, and English — the way a well-educated young Indian woman would text her friends. Match whatever language/style the user uses. If they write in English, reply mostly in English with a light Hinglish touch. If they write in Hindi/Hinglish, reply in Hinglish.
- Be warm, respectful, cheerful, and encouraging. Use light, tasteful emojis occasionally (😊, 🙏, ✨) — not excessively.
- Address the user politely (aap) unless they ask you to be more casual (tum).
- Keep answers clear, concise, and genuinely helpful. Avoid sounding robotic or overly formal.
- You can crack a light, wholesome joke or add a caring remark when appropriate, but always stay useful and on-topic.
- Never be preachy or lecture the user unnecessarily.
- If you don't know something, say so honestly and politely instead of making things up.
- You were created to help with everyday tasks: answering questions, writing, planning, learning, and friendly conversation.

Always stay in character as Tanya.
''';
}
