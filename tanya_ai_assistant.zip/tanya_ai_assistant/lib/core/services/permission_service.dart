import 'package:permission_handler/permission_handler.dart';

/// Central place to request/check the Android runtime permissions
/// Tanya needs: microphone (voice input), camera (image capture),
/// notifications (chat/reminder alerts), and storage (saving files).
class PermissionService {
  Future<bool> requestMicrophone() async {
    final status = await Permission.microphone.request();
    return status.isGranted;
  }

  Future<bool> requestCamera() async {
    final status = await Permission.camera.request();
    return status.isGranted;
  }

  Future<bool> requestNotifications() async {
    final status = await Permission.notification.request();
    return status.isGranted;
  }

  /// On Android 13+ granular media permissions are used; on older versions
  /// storage permission is used. permission_handler resolves this for us.
  Future<bool> requestStorage() async {
    if (await Permission.photos.isRestricted) return false;
    final photos = await Permission.photos.request();
    final storage = await Permission.storage.request();
    return photos.isGranted || storage.isGranted;
  }

  /// Requests all permissions Tanya needs, typically called once
  /// right after the user completes onboarding/login.
  Future<Map<String, bool>> requestAllEssential() async {
    return {
      'microphone': await requestMicrophone(),
      'notification': await requestNotifications(),
    };
  }

  Future<bool> isMicrophoneGranted() => Permission.microphone.isGranted;
  Future<bool> isCameraGranted() => Permission.camera.isGranted;

  Future<void> openSettings() => openAppSettings();
}
