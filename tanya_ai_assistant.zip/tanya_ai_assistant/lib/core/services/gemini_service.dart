import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import '../constants/app_constants.dart';

/// Wraps the Gemini API (free tier) and injects Tanya's personality
/// via a system instruction so every reply feels consistent.
class GeminiService {
  GenerativeModel? _model;
  ChatSession? _chatSession;

  GeminiService() {
    _init();
  }

  void _init() {
    final apiKey = dotenv.env['GEMINI_API_KEY'];
    if (apiKey == null || apiKey.isEmpty || apiKey == 'your_gemini_api_key_here') {
      // Left null on purpose — sendMessage() will surface a friendly error
      // instead of crashing when no key has been configured yet.
      return;
    }
    _model = GenerativeModel(
      model: AppConstants.geminiModel,
      apiKey: apiKey,
      systemInstruction: Content.system(AppConstants.tanyaSystemPrompt),
      generationConfig: GenerationConfig(
        temperature: 0.9,
        topP: 0.95,
        maxOutputTokens: 1024,
      ),
      safetySettings: [
        SafetySetting(HarmCategory.harassment, HarmBlockThreshold.medium),
        SafetySetting(HarmCategory.hateSpeech, HarmBlockThreshold.medium),
        SafetySetting(HarmCategory.sexuallyExplicit, HarmBlockThreshold.medium),
        SafetySetting(HarmCategory.dangerousContent, HarmBlockThreshold.medium),
      ],
    );
  }

  bool get isConfigured => _model != null;

  /// Starts (or restarts) a fresh multi-turn chat session, optionally
  /// seeded with prior history (used when re-opening a saved conversation).
  void startSession({List<Content>? history}) {
    if (_model == null) return;
    _chatSession = _model!.startChat(history: history);
  }

  /// Sends [prompt] to Gemini and returns Tanya's reply text.
  /// Throws a human-readable exception on failure so the UI can show it.
  Future<String> sendMessage(String prompt) async {
    if (_model == null) {
      throw Exception(
        'Gemini API key nahi mila. Please .env file mein GEMINI_API_KEY set karein.',
      );
    }
    _chatSession ??= _model!.startChat();

    try {
      final response = await _chatSession!.sendMessage(Content.text(prompt));
      final text = response.text?.trim();
      if (text == null || text.isEmpty) {
        return "Sorry, main abhi is baare mein kuch nahi keh paa rahi. Kya aap dobara try kar sakte hain? 🙏";
      }
      return text;
    } catch (e) {
      throw Exception('Tanya ko jawab dete waqt error aaya: ${e.toString()}');
    }
  }
}
