import 'package:connectivity_plus/connectivity_plus.dart';

/// Simple wrapper around connectivity_plus so the rest of the app can
/// check/subscribe to online-offline status without depending on the
/// plugin directly (easier to swap/mock later).
class ConnectivityService {
  final Connectivity _connectivity = Connectivity();

  Future<bool> isOnline() async {
    final result = await _connectivity.checkConnectivity();
    return !result.contains(ConnectivityResult.none);
  }

  Stream<bool> get onConnectivityChanged =>
      _connectivity.onConnectivityChanged.map((result) => !result.contains(ConnectivityResult.none));
}
