import 'package:cloud_firestore/cloud_firestore.dart';
import '../constants/app_constants.dart';
import '../../models/message_model.dart';
import '../../models/chat_session_model.dart';

/// Handles reading/writing chat sessions and messages to Cloud Firestore.
/// Structure: users/{uid}/chats/{chatId}/messages/{messageId}
class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> _chatsRef(String uid) => _db
      .collection(AppConstants.usersCollection)
      .doc(uid)
      .collection(AppConstants.chatsCollection);

  CollectionReference<Map<String, dynamic>> _messagesRef(String uid, String chatId) =>
      _chatsRef(uid).doc(chatId).collection(AppConstants.messagesSubcollection);

  /// Creates a new chat session document and returns its id.
  Future<String> createChatSession(String uid, {String title = 'New Chat'}) async {
    final doc = _chatsRef(uid).doc();
    final session = ChatSessionModel(
      id: doc.id,
      title: title,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
      lastMessagePreview: '',
    );
    await doc.set(session.toMap());
    return doc.id;
  }

  Future<void> updateChatSessionMeta(
    String uid,
    String chatId, {
    required String title,
    required String lastMessagePreview,
  }) async {
    await _chatsRef(uid).doc(chatId).set({
      'title': title,
      'lastMessagePreview': lastMessagePreview,
      'updatedAt': DateTime.now().toIso8601String(),
    }, SetOptions(merge: true));
  }

  Stream<List<ChatSessionModel>> streamChatSessions(String uid) {
    return _chatsRef(uid).orderBy('updatedAt', descending: true).snapshots().map(
          (snap) => snap.docs.map((d) => ChatSessionModel.fromMap(d.data())).toList(),
        );
  }

  Future<void> deleteChatSession(String uid, String chatId) async {
    final messages = await _messagesRef(uid, chatId).get();
    final batch = _db.batch();
    for (final doc in messages.docs) {
      batch.delete(doc.reference);
    }
    batch.delete(_chatsRef(uid).doc(chatId));
    await batch.commit();
  }

  Future<void> addMessage(String uid, MessageModel message) async {
    await _messagesRef(uid, message.chatId).doc(message.id).set(message.toMap());
  }

  Stream<List<MessageModel>> streamMessages(String uid, String chatId) {
    return _messagesRef(uid, chatId).orderBy('timestamp').snapshots().map(
          (snap) => snap.docs.map((d) => MessageModel.fromMap(d.data())).toList(),
        );
  }

  Future<List<MessageModel>> fetchMessagesOnce(String uid, String chatId) async {
    final snap = await _messagesRef(uid, chatId).orderBy('timestamp').get();
    return snap.docs.map((d) => MessageModel.fromMap(d.data())).toList();
  }
}
