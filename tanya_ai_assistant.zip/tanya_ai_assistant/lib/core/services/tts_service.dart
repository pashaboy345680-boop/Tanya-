import 'dart:async';
import 'package:flutter_tts/flutter_tts.dart';

/// Wraps flutter_tts so Tanya can speak her replies aloud.
/// Auto-detects whether text is mostly Hindi/Devanagari or Latin script
/// and switches the TTS language accordingly for more natural pronunciation.
class TtsService {
  final FlutterTts _tts = FlutterTts();
  bool _isSpeaking = false;

  bool get isSpeaking => _isSpeaking;

  Future<void> init() async {
    await _tts.setSpeechRate(0.48);
    await _tts.setPitch(1.05); // slightly higher pitch: warm female voice
    await _tts.setVolume(1.0);

    _tts.setStartHandler(() => _isSpeaking = true);
    _tts.setCompletionHandler(() => _isSpeaking = false);
    _tts.setCancelHandler(() => _isSpeaking = false);
    _tts.setErrorHandler((msg) => _isSpeaking = false);
  }

  bool _containsDevanagari(String text) {
    final devanagariRegex = RegExp(r'[\u0900-\u097F]');
    return devanagariRegex.hasMatch(text);
  }

  /// Speaks [text]. Picks hi-IN for Devanagari-heavy text, otherwise en-IN
  /// (which pronounces Hinglish/Romanized Hindi reasonably naturally).
  Future<void> speak(String text) async {
    if (text.trim().isEmpty) return;
    final language = _containsDevanagari(text) ? 'hi-IN' : 'en-IN';
    try {
      await _tts.setLanguage(language);
    } catch (_) {
      await _tts.setLanguage('en-US');
    }
    await _tts.speak(text);
  }

  Future<void> stop() async {
    await _tts.stop();
    _isSpeaking = false;
  }
}
