import 'package:speech_to_text/speech_to_text.dart';

/// Wraps speech_to_text to capture the user's voice and convert it to text.
/// Defaults to Hindi (India) locale but falls back to English if unavailable.
class SttService {
  final SpeechToText _speech = SpeechToText();
  bool _isAvailable = false;

  bool get isListening => _speech.isListening;

  Future<bool> init() async {
    _isAvailable = await _speech.initialize(
      onError: (err) => print('STT error: ${err.errorMsg}'),
      onStatus: (status) => print('STT status: $status'),
    );
    return _isAvailable;
  }

  /// Starts listening. [onResult] is called with the live/final transcript.
  Future<void> startListening({
    required Function(String text, bool isFinal) onResult,
  }) async {
    if (!_isAvailable) {
      final ok = await init();
      if (!ok) return;
    }

    String localeId = 'en_IN';
    try {
      final locales = await _speech.locales();
      final hindi = locales.where((l) => l.localeId.startsWith('hi')).toList();
      if (hindi.isNotEmpty) localeId = hindi.first.localeId;
    } catch (_) {
      // fall back to en_IN
    }

    await _speech.listen(
      onResult: (result) {
        onResult(result.recognizedWords, result.finalResult);
      },
      localeId: localeId,
      listenMode: ListenMode.confirmation,
      pauseFor: const Duration(seconds: 3),
    );
  }

  Future<void> stopListening() async {
    await _speech.stop();
  }

  Future<void> cancel() async {
    await _speech.cancel();
  }
}
