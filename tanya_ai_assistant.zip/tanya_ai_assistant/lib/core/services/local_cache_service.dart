import 'package:hive_flutter/hive_flutter.dart';
import '../constants/app_constants.dart';
import '../../models/message_model.dart';

/// Handles offline message caching using Hive so the chat history is
/// available instantly (and usable) even without an internet connection.
/// Messages sent while offline are queued in [pendingMessagesBox] and
/// flushed to Firestore once connectivity returns (see ChatProvider).
class LocalCacheService {
  Box<MessageModel>? _messagesBox;
  Box<MessageModel>? _pendingBox;

  Future<void> init() async {
    _messagesBox = await Hive.openBox<MessageModel>(AppConstants.messagesBox);
    _pendingBox = await Hive.openBox<MessageModel>(AppConstants.pendingMessagesBox);
  }

  // ----- Cached (already-synced) messages, keyed by message id -----

  Future<void> cacheMessage(MessageModel message) async {
    await _messagesBox?.put(message.id, message);
  }

  List<MessageModel> getCachedMessagesForChat(String chatId) {
    final all = _messagesBox?.values.where((m) => m.chatId == chatId).toList() ?? [];
    all.sort((a, b) => a.timestamp.compareTo(b.timestamp));
    return all;
  }

  Future<void> cacheAllMessages(List<MessageModel> messages) async {
    if (_messagesBox == null) return;
    final map = {for (final m in messages) m.id: m};
    await _messagesBox!.putAll(map);
  }

  // ----- Pending (not-yet-synced) messages queue -----

  Future<void> queuePendingMessage(MessageModel message) async {
    await _pendingBox?.put(message.id, message);
  }

  List<MessageModel> getAllPendingMessages() {
    return _pendingBox?.values.toList() ?? [];
  }

  Future<void> removePendingMessage(String id) async {
    await _pendingBox?.delete(id);
  }

  Future<void> clearChatCache(String chatId) async {
    if (_messagesBox == null) return;
    final keysToDelete = _messagesBox!.keys.where((key) {
      final msg = _messagesBox!.get(key);
      return msg?.chatId == chatId;
    }).toList();
    await _messagesBox!.deleteAll(keysToDelete);
  }
}
