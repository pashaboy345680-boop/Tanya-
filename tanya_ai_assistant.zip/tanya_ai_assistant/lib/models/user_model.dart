/// Represents the currently signed-in user's profile, backed by Firestore.
class UserModel {
  final String uid;
  final String name;
  final String email;
  final String? photoUrl;
  final DateTime createdAt;
  final String preferredLanguage; // "hindi" | "hinglish" | "english"

  UserModel({
    required this.uid,
    required this.name,
    required this.email,
    this.photoUrl,
    required this.createdAt,
    this.preferredLanguage = 'hinglish',
  });

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'name': name,
      'email': email,
      'photoUrl': photoUrl,
      'createdAt': createdAt.toIso8601String(),
      'preferredLanguage': preferredLanguage,
    };
  }

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      uid: map['uid'] as String,
      name: map['name'] as String? ?? 'Dost',
      email: map['email'] as String? ?? '',
      photoUrl: map['photoUrl'] as String?,
      createdAt: map['createdAt'] != null
          ? DateTime.tryParse(map['createdAt'] as String) ?? DateTime.now()
          : DateTime.now(),
      preferredLanguage: map['preferredLanguage'] as String? ?? 'hinglish',
    );
  }

  UserModel copyWith({String? name, String? photoUrl, String? preferredLanguage}) {
    return UserModel(
      uid: uid,
      name: name ?? this.name,
      email: email,
      photoUrl: photoUrl ?? this.photoUrl,
      createdAt: createdAt,
      preferredLanguage: preferredLanguage ?? this.preferredLanguage,
    );
  }
}
