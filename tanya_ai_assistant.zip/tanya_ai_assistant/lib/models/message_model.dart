import 'package:hive/hive.dart';

part 'message_model.g.dart';

/// Represents a single chat message, either from the user or from Tanya.
/// Stored both in Firestore (when online) and Hive (for offline caching).
@HiveType(typeId: 0)
class MessageModel extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String chatId;

  @HiveField(2)
  final String text;

  @HiveField(3)
  final bool isUser;

  @HiveField(4)
  final DateTime timestamp;

  @HiveField(5)
  final bool isSynced; // false = still pending upload to Firestore (offline)

  @HiveField(6)
  final String? imagePath; // optional local image attachment path

  MessageModel({
    required this.id,
    required this.chatId,
    required this.text,
    required this.isUser,
    required this.timestamp,
    this.isSynced = true,
    this.imagePath,
  });

  MessageModel copyWith({bool? isSynced}) {
    return MessageModel(
      id: id,
      chatId: chatId,
      text: text,
      isUser: isUser,
      timestamp: timestamp,
      isSynced: isSynced ?? this.isSynced,
      imagePath: imagePath,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'chatId': chatId,
      'text': text,
      'isUser': isUser,
      'timestamp': timestamp.toIso8601String(),
      'imagePath': imagePath,
    };
  }

  factory MessageModel.fromMap(Map<String, dynamic> map) {
    return MessageModel(
      id: map['id'] as String,
      chatId: map['chatId'] as String,
      text: map['text'] as String,
      isUser: map['isUser'] as bool,
      timestamp: DateTime.parse(map['timestamp'] as String),
      isSynced: true,
      imagePath: map['imagePath'] as String?,
    );
  }
}
