/// Represents one conversation "thread" shown in the History screen.
/// Each chat session groups a set of messages under one Firestore document.
class ChatSessionModel {
  final String id;
  final String title; // auto-generated from the first user message
  final DateTime createdAt;
  final DateTime updatedAt;
  final String lastMessagePreview;

  ChatSessionModel({
    required this.id,
    required this.title,
    required this.createdAt,
    required this.updatedAt,
    required this.lastMessagePreview,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
      'lastMessagePreview': lastMessagePreview,
    };
  }

  factory ChatSessionModel.fromMap(Map<String, dynamic> map) {
    return ChatSessionModel(
      id: map['id'] as String,
      title: map['title'] as String? ?? 'New Chat',
      createdAt: DateTime.tryParse(map['createdAt'] as String? ?? '') ?? DateTime.now(),
      updatedAt: DateTime.tryParse(map['updatedAt'] as String? ?? '') ?? DateTime.now(),
      lastMessagePreview: map['lastMessagePreview'] as String? ?? '',
    );
  }
}
