import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/services/stt_service.dart';
import '../../core/services/permission_service.dart';
import '../../providers/auth_provider.dart';
import '../../providers/chat_provider.dart';
import '../../providers/settings_provider.dart';
import '../../widgets/chat_bubble.dart';
import '../../widgets/chat_input_bar.dart';
import '../../widgets/typing_indicator.dart';
import '../history/history_screen.dart';
import '../settings/settings_screen.dart';
import '../profile/profile_screen.dart';

/// Tanya's main conversation screen — where the user actually chats with
/// her via text or voice, sees her replies, and can hear them spoken aloud.
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _textController = TextEditingController();
  final _scrollController = ScrollController();
  final _sttService = SttService();
  final _permissionService = PermissionService();
  bool _isListening = false;
  bool _initDone = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _bootstrap());
  }

  Future<void> _bootstrap() async {
    final auth = context.read<AuthProvider>();
    final chat = context.read<ChatProvider>();
    if (auth.currentUser == null) return;

    await chat.init(auth.currentUser!.uid);
    if (chat.activeChatId == null) {
      await chat.startNewChat();
    }
    // Ask for essential permissions the first time chat opens.
    await _permissionService.requestAllEssential();
    setState(() => _initDone = true);
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent + 80,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _sendMessage() async {
    final text = _textController.text;
    if (text.trim().isEmpty) return;
    _textController.clear();
    final chat = context.read<ChatProvider>();
    final settings = context.read<SettingsProvider>();
    await chat.sendMessage(text);
    _scrollToBottom();

    if (settings.voiceRepliesEnabled && chat.messages.isNotEmpty && !chat.messages.last.isUser) {
      chat.speakText(chat.messages.last.text);
    }
  }

  Future<void> _toggleMic() async {
    final granted = await _permissionService.requestMicrophone();
    if (!granted) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Voice input ke liye microphone permission zaroori hai 🎙️')),
      );
      return;
    }

    if (_isListening) {
      await _sttService.stopListening();
      setState(() => _isListening = false);
      return;
    }

    setState(() => _isListening = true);
    await _sttService.startListening(
      onResult: (text, isFinal) {
        _textController.text = text;
        _textController.selection = TextSelection.fromPosition(
          TextPosition(offset: _textController.text.length),
        );
        if (isFinal) {
          setState(() => _isListening = false);
        }
      },
    );
  }

  @override
  void dispose() {
    _textController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    final chat = context.watch<ChatProvider>();
    final isDark = settings.isDarkMode;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: const BoxDecoration(
                gradient: LinearGradient(colors: AppColors.heroGradient),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.auto_awesome, size: 18, color: Colors.white),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Tanya', style: TextStyle(fontSize: 17)),
                Text(
                  chat.isOnline ? 'Online' : 'Offline mode',
                  style: TextStyle(
                    fontSize: 11,
                    color: chat.isOnline ? AppColors.success : AppColors.warning,
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.history_rounded),
            tooltip: 'History',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const HistoryScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.add_comment_outlined),
            tooltip: 'New chat',
            onPressed: () async {
              await context.read<ChatProvider>().startNewChat();
            },
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert_rounded),
            onSelected: (value) {
              if (value == 'settings') {
                Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsScreen()));
              } else if (value == 'profile') {
                Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ProfileScreen()));
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'profile', child: Text('Profile')),
              PopupMenuItem(value: 'settings', child: Text('Settings')),
            ],
          ),
        ],
      ),
      body: !_initDone
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                if (!chat.isGeminiConfigured)
                  Container(
                    width: double.infinity,
                    color: AppColors.warning.withOpacity(0.15),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    child: const Text(
                      '⚠️ Gemini API key configure nahi hai. .env file mein GEMINI_API_KEY daalein.',
                      style: TextStyle(fontSize: 12.5),
                    ),
                  ),
                Expanded(
                  child: chat.messages.isEmpty
                      ? _buildEmptyState(context, isDark)
                      : ListView.builder(
                          controller: _scrollController,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          itemCount: chat.messages.length + (chat.isTanyaTyping ? 1 : 0),
                          itemBuilder: (context, index) {
                            if (index == chat.messages.length) {
                              return TypingIndicator(isDark: isDark);
                            }
                            final message = chat.messages[index];
                            return ChatBubble(
                              message: message,
                              isDark: isDark,
                              onSpeakTap: () => chat.speakText(message.text),
                            );
                          },
                        ),
                ),
                ChatInputBar(
                  controller: _textController,
                  onSend: _sendMessage,
                  onMicTap: _toggleMic,
                  isListening: _isListening,
                  isDark: isDark,
                ),
              ],
            ),
    );
  }

  Widget _buildEmptyState(BuildContext context, bool isDark) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 90,
              height: 90,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: AppColors.heroGradient),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(color: AppColors.primary.withOpacity(0.35), blurRadius: 24),
                ],
              ),
              child: const Icon(Icons.waving_hand_rounded, color: Colors.white, size: 40),
            ),
            const SizedBox(height: 20),
            Text(
              'Namaste! Main Tanya hoon 😊',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w600),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              'Aap mujhse kuch bhi pooch sakte hain — Hindi, Hinglish ya English mein. Chaliye baat shuru karte hain!',
              textAlign: TextAlign.center,
              style: TextStyle(color: isDark ? Colors.white60 : Colors.black54),
            ),
          ],
        ),
      ),
    );
  }
}
