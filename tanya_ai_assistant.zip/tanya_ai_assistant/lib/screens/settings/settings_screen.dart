import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/services/permission_service.dart';
import '../../providers/settings_provider.dart';
import '../../providers/auth_provider.dart';
import '../auth/login_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    final permissionService = PermissionService();

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _SectionTitle('Appearance'),
          Card(
            child: SwitchListTile(
              title: const Text('Dark Mode'),
              subtitle: const Text('Tanya ka premium dark theme'),
              value: settings.isDarkMode,
              activeColor: AppColors.primary,
              onChanged: (val) => settings.toggleDarkMode(val),
            ),
          ),
          const SizedBox(height: 20),
          _SectionTitle('Voice & Language'),
          Card(
            child: Column(
              children: [
                SwitchListTile(
                  title: const Text('Voice Replies'),
                  subtitle: const Text('Tanya apne jawab bol kar bhi sunaayegi'),
                  value: settings.voiceRepliesEnabled,
                  activeColor: AppColors.primary,
                  onChanged: (val) => settings.toggleVoiceReplies(val),
                ),
                const Divider(height: 1),
                ListTile(
                  title: const Text('Preferred Reply Language'),
                  subtitle: Text(_languageLabel(settings.preferredLanguage)),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _showLanguagePicker(context, settings),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _SectionTitle('Permissions'),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.mic_none_rounded),
                  title: const Text('Microphone'),
                  subtitle: const Text('Voice input ke liye'),
                  trailing: TextButton(
                    onPressed: () => permissionService.requestMicrophone(),
                    child: const Text('Allow'),
                  ),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.camera_alt_outlined),
                  title: const Text('Camera'),
                  subtitle: const Text('Photo capture ke liye'),
                  trailing: TextButton(
                    onPressed: () => permissionService.requestCamera(),
                    child: const Text('Allow'),
                  ),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.notifications_none_rounded),
                  title: const Text('Notifications'),
                  subtitle: const Text('Updates aur reminders ke liye'),
                  trailing: TextButton(
                    onPressed: () => permissionService.requestNotifications(),
                    child: const Text('Allow'),
                  ),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.folder_open_outlined),
                  title: const Text('Storage'),
                  subtitle: const Text('Files save karne ke liye'),
                  trailing: TextButton(
                    onPressed: () => permissionService.requestStorage(),
                    child: const Text('Allow'),
                  ),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.settings_outlined),
                  title: const Text('Open App Settings'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => permissionService.openSettings(),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _SectionTitle('Account'),
          Card(
            child: ListTile(
              leading: const Icon(Icons.logout_rounded, color: AppColors.error),
              title: const Text('Logout', style: TextStyle(color: AppColors.error)),
              onTap: () async {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (_) => AlertDialog(
                    title: const Text('Logout karein?'),
                    content: const Text('Kya aap sach mein logout karna chahte hain?'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                      TextButton(
                          onPressed: () => Navigator.pop(context, true),
                          child: const Text('Logout', style: TextStyle(color: AppColors.error))),
                    ],
                  ),
                );
                if (confirm == true && context.mounted) {
                  await context.read<AuthProvider>().signOut();
                  if (context.mounted) {
                    Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(builder: (_) => const LoginScreen()),
                      (route) => false,
                    );
                  }
                }
              },
            ),
          ),
          const SizedBox(height: 24),
          Center(
            child: Text(
              'Tanya v1.0.0',
              style: TextStyle(color: Theme.of(context).textTheme.bodyMedium?.color?.withOpacity(0.4)),
            ),
          ),
        ],
      ),
    );
  }

  String _languageLabel(String code) {
    switch (code) {
      case 'hindi':
        return 'Hindi';
      case 'english':
        return 'English';
      default:
        return 'Hinglish (Mixed)';
    }
  }

  void _showLanguagePicker(BuildContext context, SettingsProvider settings) {
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Preferred Language', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
            ),
            ListTile(
              title: const Text('Hinglish (Mixed)'),
              trailing: settings.preferredLanguage == 'hinglish' ? const Icon(Icons.check, color: AppColors.primary) : null,
              onTap: () {
                settings.setPreferredLanguage('hinglish');
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: const Text('Hindi'),
              trailing: settings.preferredLanguage == 'hindi' ? const Icon(Icons.check, color: AppColors.primary) : null,
              onTap: () {
                settings.setPreferredLanguage('hindi');
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: const Text('English'),
              trailing: settings.preferredLanguage == 'english' ? const Icon(Icons.check, color: AppColors.primary) : null,
              onTap: () {
                settings.setPreferredLanguage('english');
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 8),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w600,
          color: Theme.of(context).textTheme.bodyMedium?.color?.withOpacity(0.5),
          letterSpacing: 0.5,
        ),
      ),
    );
  }
}
