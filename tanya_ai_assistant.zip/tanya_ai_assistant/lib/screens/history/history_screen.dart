import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/chat_provider.dart';
import '../../models/chat_session_model.dart';
import '../chat/chat_screen.dart';

/// Lists all of the user's past conversations with Tanya, newest first.
/// Tapping a conversation re-opens it in the chat screen.
class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final chatProvider = context.read<ChatProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Conversation History')),
      body: StreamBuilder<List<ChatSessionModel>>(
        stream: chatProvider.chatSessionsStream(),
        builder: (context, snapshot) {
          if (!chatProvider.isOnline) {
            return const _OfflineHistoryNotice();
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final sessions = snapshot.data ?? [];
          if (sessions.isEmpty) {
            return Center(
              child: Text(
                'Abhi koi purani baat-cheet nahi hai.\nTanya se chat shuru karein! 💬',
                textAlign: TextAlign.center,
                style: TextStyle(color: Theme.of(context).textTheme.bodyMedium?.color?.withOpacity(0.6)),
              ),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: sessions.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final session = sessions[index];
              return Card(
                margin: EdgeInsets.zero,
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  leading: const CircleAvatar(
                    backgroundColor: AppColors.primary,
                    child: Icon(Icons.chat_bubble_outline, color: Colors.white, size: 18),
                  ),
                  title: Text(
                    session.title.isEmpty ? 'New Chat' : session.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                  subtitle: Text(
                    '${session.lastMessagePreview}\n${DateFormat('d MMM, h:mm a').format(session.updatedAt)}',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  isThreeLine: true,
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline, color: AppColors.error, size: 20),
                    onPressed: () async {
                      final confirm = await showDialog<bool>(
                        context: context,
                        builder: (_) => AlertDialog(
                          title: const Text('Chat delete karein?'),
                          content: const Text('Yeh conversation permanently delete ho jaayegi.'),
                          actions: [
                            TextButton(
                                onPressed: () => Navigator.pop(context, false),
                                child: const Text('Cancel')),
                            TextButton(
                                onPressed: () => Navigator.pop(context, true),
                                child: const Text('Delete', style: TextStyle(color: AppColors.error))),
                          ],
                        ),
                      );
                      if (confirm == true) {
                        await chatProvider.deleteChat(session.id);
                      }
                    },
                  ),
                  onTap: () async {
                    await chatProvider.openChat(session.id);
                    if (context.mounted) {
                      Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (_) => const ChatScreen()),
                      );
                    }
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class _OfflineHistoryNotice extends StatelessWidget {
  const _OfflineHistoryNotice();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.cloud_off_rounded, size: 48, color: AppColors.warning),
            const SizedBox(height: 16),
            const Text(
              "Aap abhi offline hain",
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
            ),
            const SizedBox(height: 6),
            Text(
              "Poori history dekhne ke liye internet se jud jaayein. Chat screen par aapka current conversation cache se dikh raha hoga.",
              textAlign: TextAlign.center,
              style: TextStyle(color: Theme.of(context).textTheme.bodyMedium?.color?.withOpacity(0.6)),
            ),
          ],
        ),
      ),
    );
  }
}
