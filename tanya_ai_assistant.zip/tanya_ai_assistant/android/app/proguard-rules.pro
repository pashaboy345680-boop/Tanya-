# Keep Firebase classes
-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }

# Keep Gemini / Google Generative AI SDK
-keep class com.google.ai.** { *; }

# Keep Hive generated adapters
-keep class ** extends com.hivedb.hive.** { *; }

# General Kotlin/Flutter safety
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn kotlin.**
