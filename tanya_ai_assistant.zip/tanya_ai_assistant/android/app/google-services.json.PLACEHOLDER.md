# google-services.json goes here

This project needs your own Firebase project's `google-services.json` file
placed at `android/app/google-services.json` (same folder as this file).

## How to get it (free, ~2 minutes)
1. Go to https://console.firebase.google.com and create a new project (free "Spark" plan).
2. Click **Add app > Android**.
3. Enter package name: `com.tanya.ai_assistant` (must match `applicationId` in `android/app/build.gradle`).
4. Download the generated `google-services.json` file.
5. Place it at `android/app/google-services.json` — replacing this placeholder note.
6. Also run `flutterfire configure` from the project root to regenerate `lib/firebase_options.dart` with your real project keys.

Then in the Firebase Console, enable:
- **Authentication > Sign-in method > Email/Password**
- **Firestore Database > Create database** (start in test mode, then apply the security rules from `firestore.rules` in this project)
